---
name: Feature Request
about: Suggest a new risk check, platform, or tool improvement
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

## Summary
A one-sentence description of the feature.

## Problem It Solves
What scam vector or workflow gap does this address?

## Proposed Solution
How should it work? Include pseudocode or examples if possible.

## Alternatives Considered
Other approaches you thought about.

## Additional Context
Links to relevant contracts, research, or similar tools that implement this.
