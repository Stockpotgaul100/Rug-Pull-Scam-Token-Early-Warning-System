---
name: Bug Report
about: Something is broken or producing incorrect results
title: "[BUG] "
labels: bug
assignees: ''
---

## Describe the Bug
A clear description of what went wrong.

## Command Used
```bash
python -m src.main 0x... --token XYZ
```

## Expected Behavior
What you expected to happen.

## Actual Behavior
What actually happened. Paste the full terminal output below (redact any API keys).

```
paste output here
```

## Environment
- OS: [e.g. Windows 11, Ubuntu 22.04, macOS 14]
- Python version: [e.g. 3.11.2]
- web3.py version: [run `pip show web3`]
- RPC endpoint type: [e.g. LlamaRPC, Alchemy, Infura]

## Contract Address (if applicable)
If the bug is related to a specific contract, provide the address. Testnet addresses preferred.

`0x...`

## Additional Context
Any other context, screenshots, or notes.
