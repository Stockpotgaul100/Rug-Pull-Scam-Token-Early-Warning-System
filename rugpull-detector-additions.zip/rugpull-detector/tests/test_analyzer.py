"""
Tests for RugPull Detector — contract analyzer and social collector.
Run: pytest tests/ -v
"""

import pytest
from unittest.mock import MagicMock, patch
from src.analyzers.contract_analyzer import ContractAnalyzer, ContractRisk, RISK_THRESHOLDS
from src.collectors.social_collector import SocialCollector
from src.utils.report import generate_report, _score_to_level


# ─────────────────────────────────────────────
# ContractAnalyzer unit tests
# ─────────────────────────────────────────────

class TestRiskScoring:
    def test_score_to_level_low(self):
        assert _score_to_level(0) == "low"
        assert _score_to_level(29) == "low"

    def test_score_to_level_medium(self):
        assert _score_to_level(30) == "medium"
        assert _score_to_level(59) == "medium"

    def test_score_to_level_high(self):
        assert _score_to_level(60) == "high"
        assert _score_to_level(79) == "high"

    def test_score_to_level_critical(self):
        assert _score_to_level(80) == "critical"
        assert _score_to_level(100) == "critical"

    def test_score_capped_at_100(self):
        risk = ContractRisk(address="0x0", score=150)
        risk.score = min(100, risk.score)
        assert risk.score == 100

    def test_contract_risk_to_dict(self):
        risk = ContractRisk(
            address="0xDEAD",
            score=42,
            level="medium",
            flags=["mint_function"],
            details={"mint_function": "Mint detected"},
        )
        d = risk.to_dict()
        assert d["address"] == "0xDEAD"
        assert d["score"] == 42
        assert "mint_function" in d["flags"]


class TestHoneypotPatterns:
    def test_detect_blacklist_pattern(self):
        analyzer = _mock_analyzer()
        risk = ContractRisk(address="0x0")
        source = "mapping(address => bool) private _isBlacklisted;"
        analyzer._scan_source_patterns(source, risk)
        assert "blacklist_function" in risk.flags

    def test_detect_fee_manipulation(self):
        analyzer = _mock_analyzer()
        risk = ContractRisk(address="0x0")
        source = "function setFee(uint256 fee) external { _taxFee = 99; }"
        analyzer._scan_source_patterns(source, risk)
        assert "fee_manipulation" in risk.flags

    def test_clean_source_no_flags(self):
        analyzer = _mock_analyzer()
        risk = ContractRisk(address="0x0")
        source = "function transfer(address to, uint256 amount) external returns (bool) {}"
        analyzer._scan_source_patterns(source, risk)
        assert risk.flags == []


# ─────────────────────────────────────────────
# SocialCollector unit tests
# ─────────────────────────────────────────────

class TestSocialCollector:
    def test_score_text_pump_phrases(self):
        text = "This is the next 100x hidden gem! 🚀🚀🚀 Don't miss it!"
        result = SocialCollector.score_text(text)
        assert result["pump"] > 0
        assert result["urgency"] > 0

    def test_score_text_clean(self):
        text = "This token implements ERC-20 with a fixed supply of 1 billion tokens."
        result = SocialCollector.score_text(text)
        assert result["pump"] == 0
        assert result["urgency"] == 0

    def test_score_text_fake_team(self):
        text = "Our fully doxxed team includes ex-Google and ex-Binance veterans."
        result = SocialCollector.score_text(text)
        assert result["fake_team"] > 0

    def test_no_token_no_twitter_skips(self):
        collector = SocialCollector()  # No keys
        report = collector.analyze("TESTTOKEN", None)
        # CoinGecko may return, twitter/telegram should be skipped
        platforms = [s.platform for s in report.signals]
        assert "twitter" not in platforms
        assert "telegram" not in platforms


# ─────────────────────────────────────────────
# Report generator tests
# ─────────────────────────────────────────────

class TestReportGenerator:
    def test_report_structure(self):
        risk = ContractRisk(address="0xABC", score=75, level="high", flags=["mint_function"])
        report = generate_report(risk)
        assert "overall_score" in report
        assert "overall_level" in report
        assert "contract" in report
        assert "recommendation" in report
        assert report["social"] is None

    def test_combined_score_weighted(self):
        from src.collectors.social_collector import SocialReport, SocialSignal
        risk = ContractRisk(address="0xABC", score=80, level="critical")
        social = SocialReport(token_name="SCAM", combined_score=60)
        social.signals.append(SocialSignal(platform="twitter", score=60))
        report = generate_report(risk, social)
        # 80 * 0.7 + 60 * 0.3 = 74
        assert report["overall_score"] == 74

    def test_recommendation_critical(self):
        risk = ContractRisk(address="0x0", score=95, level="critical")
        report = generate_report(risk)
        assert "CRITICAL" in report["recommendation"]

    def test_recommendation_low(self):
        risk = ContractRisk(address="0x0", score=10, level="low")
        report = generate_report(risk)
        assert "LOW RISK" in report["recommendation"]


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def _mock_analyzer() -> ContractAnalyzer:
    """Returns a ContractAnalyzer with a mocked Web3 connection."""
    with patch("src.analyzers.contract_analyzer.Web3") as MockWeb3:
        instance = MockWeb3.return_value
        instance.is_connected.return_value = True
        instance.eth.chain_id = 1
        analyzer = ContractAnalyzer.__new__(ContractAnalyzer)
        analyzer.w3 = instance
        analyzer.etherscan_key = None
        return analyzer
