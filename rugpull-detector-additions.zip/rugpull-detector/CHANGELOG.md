# Changelog

All notable changes to RugPull Detector are documented here.  
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).  
Versioning follows [Semantic Versioning](https://semver.org/).

---

## [2.7.1] — 2026-05-19

### Fixed
- CoinGecko API rate limit handling — exponential backoff on 429 responses
- Proxy detection false positive on ERC-1155 contracts
- Terminal output color codes breaking on Windows CMD (added `colorama` fallback)
- `--save` flag now creates parent directories if they don't exist

### Improved
- Etherscan source code fetch timeout increased from 5s → 10s
- Log output cleaned up — reduced noise at INFO level

---

## [2.7.0] — 2026-05-10

### Added
- **Arbitrum One** chain support (`--chain arb`)
- `--no-social` flag to skip social analysis for faster contract-only scans
- Exit codes now reflect risk level for CI/CD pipeline integration
- `contract_balance_eth` included in JSON report output

### Changed
- Risk score weighting rebalanced — `self_destruct` raised from 20 → 25
- Social combined score now weighted 70% contract / 30% social (was 50/50)

### Fixed
- `young_contract` flag triggering incorrectly on high-volume contracts

---

## [2.6.0] — 2026-04-28

### Added
- **EIP-1967 proxy contract detection** — identifies upgradeable contracts
- `fee_manipulation` check — detects dynamic tax setters with high values
- `--output both` flag — prints terminal report and JSON simultaneously
- Honeypot pattern: `cooldown[` anti-bot mechanism detection

### Changed
- Minimum Python version raised to 3.10 (uses structural pattern matching internally)
- `.env.example` updated with BSCScan key support

---

## [2.5.0] — 2026-04-10

### Added
- **BNB Smart Chain** support (`--chain bsc`)
- **Polygon** support (`--chain polygon`)
- CoinGecko integration — market cap rank and listing status checks
- `few_holders` risk flag (threshold: <50 unique holders)
- `high_owner_supply` flag — warns when top holder owns >20% of supply

### Fixed
- Web3 connection error now shows actionable RPC tip instead of raw traceback
- Ownership check no longer crashes on contracts without `Ownable`

---

## [2.4.0] — 2026-03-22

### Added
- **Twitter/X social analysis** — pump language and urgency tactic detection
- `SocialCollector.score_text()` public utility for standalone text scoring
- Fake team pattern detection (`ex-Google`, `doxxed team`, etc.)
- `--token` flag to specify token name/symbol for social analysis

### Changed
- Social report now included in JSON output under `social` key
- `PUMP_PHRASES` and `URGENCY_PHRASES` moved to module-level constants

---

## [2.3.0] — 2026-03-05

### Added
- `blacklist_function` detection via Solidity source pattern matching
- `--chain` flag (initial Ethereum-only support, multi-chain planned)
- Colorized terminal output with ASCII risk progress bar
- `RISK_THRESHOLDS` config dict for tunable level boundaries

### Fixed
- Source code scan now handles multi-file Hardhat/Foundry outputs
- Score correctly capped at 100 for contracts with many simultaneous flags

---

## [2.2.0] — 2026-02-18

### Added
- Etherscan API integration — source code verification checks
- `honeypot_pattern` detection with 5 initial Solidity patterns
- `--etherscan-key` CLI flag and `ETHERSCAN_API_KEY` env variable support
- JSON output mode (`--output json`)

---

## [2.1.0] — 2026-02-05

### Added
- `ownership_not_renounced` check — compares owner to dead addresses
- `low_liquidity` heuristic — flags contracts with <0.5 ETH balance
- `young_contract` flag based on transaction count
- `--save` flag to write report to file

### Changed
- Risk scoring now uses named `RISK_WEIGHTS` dict instead of hardcoded values

---

## [2.0.0] — 2026-01-20

### Breaking Changes
- CLI interface redesigned — `analyze.py` replaced by `python -m src.main`
- JSON output schema changed: `risk` → `contract`, added `overall_score`

### Added
- Modular architecture: `analyzers/`, `collectors/`, `utils/`
- `ContractRisk` and `SocialReport` dataclasses
- pytest test suite (`tests/test_analyzer.py`)
- `.env.example` configuration template
- 4-byte selector scan for `mint`, `blacklist`, `rescueToken`, `setFee`

---

## [1.2.0] — 2025-12-14

### Added
- `SELFDESTRUCT` opcode detection in bytecode
- Basic risk level classification (LOW / MEDIUM / HIGH / CRITICAL)
- `--rpc` CLI flag for custom RPC endpoints

---

## [1.1.0] — 2025-11-30

### Added
- Web3.py integration for live on-chain data
- Bytecode retrieval and basic analysis
- EIP-1967 implementation slot check (initial version)

---

## [1.0.0] — 2025-11-15

### Initial Release
- Basic contract address validation
- Etherscan link generator
- README with threat taxonomy
- MIT license
