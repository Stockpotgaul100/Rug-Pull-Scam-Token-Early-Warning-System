"""
Report Generator — formats ContractRisk + SocialReport into a unified output.
"""

from __future__ import annotations
import time
from typing import Optional

from src.analyzers.contract_analyzer import ContractRisk
from src.collectors.social_collector import SocialReport

# ANSI colors for terminal output
RESET  = "\033[0m"
BOLD   = "\033[1m"
RED    = "\033[91m"
YELLOW = "\033[93m"
GREEN  = "\033[92m"
CYAN   = "\033[96m"
GRAY   = "\033[90m"
WHITE  = "\033[97m"

LEVEL_COLOR = {
    "low":      GREEN,
    "medium":   YELLOW,
    "high":     RED,
    "critical": RED + BOLD,
    "unknown":  GRAY,
}

LEVEL_EMOJI = {
    "low":      "🟢",
    "medium":   "🟡",
    "high":     "🔴",
    "critical": "💀",
    "unknown":  "⬜",
}


def generate_report(
    contract: ContractRisk,
    social: Optional[SocialReport] = None,
) -> dict:
    """Merge contract and social results into a single serialisable dict."""
    overall_score = contract.score
    if social and social.signals:
        # Weighted 70% contract / 30% social
        overall_score = int(contract.score * 0.7 + social.combined_score * 0.3)

    return {
        "generated_at":   time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "overall_score":  overall_score,
        "overall_level":  _score_to_level(overall_score),
        "contract":       contract.to_dict(),
        "social":         social.to_dict() if social else None,
        "recommendation": _recommendation(overall_score),
    }


def print_terminal_report(report: dict) -> None:
    level = report["overall_level"]
    color = LEVEL_COLOR.get(level, GRAY)
    emoji = LEVEL_EMOJI.get(level, "")

    sep = f"{GRAY}{'─' * 60}{RESET}"
    print(sep)
    print(f"  {BOLD}RISK ASSESSMENT REPORT{RESET}  ·  {report['generated_at']}")
    print(sep)

    # Overall
    score = report["overall_score"]
    bar   = _score_bar(score, color)
    print(f"\n  {emoji}  Overall Risk  {color}{level.upper()}{RESET}  [{bar}]  {color}{score}/100{RESET}\n")

    # Contract section
    c = report["contract"]
    print(f"  {CYAN}{BOLD}CONTRACT ANALYSIS{RESET}  {c['address']}")
    print(f"  Score: {_colored_score(c['score'])}   Level: {_colored_level(c['level'])}")
    if c["flags"]:
        print(f"  {BOLD}Flags:{RESET}")
        for flag in c["flags"]:
            detail = c["details"].get(flag, "")
            detail_str = f"  {GRAY}→ {detail}{RESET}" if detail else ""
            print(f"    {RED}⚠{RESET}  {flag}{detail_str}")
    else:
        print(f"    {GREEN}✓  No critical flags detected{RESET}")

    # Details
    if c.get("details"):
        safe_details = {k: v for k, v in c["details"].items() if k not in c["flags"]}
        if safe_details:
            print(f"\n  {BOLD}Details:{RESET}")
            for k, v in safe_details.items():
                print(f"    {GRAY}{k}:{RESET} {v}")

    # Social section
    s = report.get("social")
    if s:
        print(f"\n{sep}")
        print(f"  {CYAN}{BOLD}SOCIAL SIGNAL ANALYSIS{RESET}  ·  {s['token_name']}")
        print(f"  Combined Score: {_colored_score(s['combined_score'])}")
        for sig in s.get("signals", []):
            plat = sig["platform"].upper()
            print(f"\n  [{plat}]  Score: {_colored_score(sig['score'])}")
            for flag in sig.get("flags", []):
                print(f"    {YELLOW}⚠{RESET}  {flag}")
            for k, v in sig.get("metrics", {}).items():
                print(f"    {GRAY}{k}:{RESET} {v}")

    # Recommendation
    print(f"\n{sep}")
    rec = report["recommendation"]
    print(f"\n  {BOLD}RECOMMENDATION:{RESET}")
    print(f"  {color}{rec}{RESET}\n")
    print(sep)


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def _score_bar(score: int, color: str = "", width: int = 20) -> str:
    filled = round(score / 100 * width)
    return f"{color}{'█' * filled}{'░' * (width - filled)}{RESET}"


def _colored_score(score: int) -> str:
    if score >= 80:
        c = RED + BOLD
    elif score >= 60:
        c = RED
    elif score >= 30:
        c = YELLOW
    else:
        c = GREEN
    return f"{c}{score}/100{RESET}"


def _colored_level(level: str) -> str:
    c = LEVEL_COLOR.get(level, GRAY)
    return f"{c}{level.upper()}{RESET}"


def _score_to_level(score: int) -> str:
    if score >= 80:
        return "critical"
    if score >= 60:
        return "high"
    if score >= 30:
        return "medium"
    return "low"


def _recommendation(score: int) -> str:
    if score >= 80:
        return (
            "CRITICAL RISK — Multiple severe red flags detected. "
            "Do NOT interact with this contract. High probability of malicious intent."
        )
    if score >= 60:
        return (
            "HIGH RISK — Significant warning signs found. "
            "Exercise extreme caution. Do not invest without independent verification."
        )
    if score >= 30:
        return (
            "MEDIUM RISK — Some suspicious patterns detected. "
            "Proceed with caution and conduct thorough due diligence."
        )
    return (
        "LOW RISK — No critical flags found. "
        "Standard due diligence still recommended before any investment."
    )
