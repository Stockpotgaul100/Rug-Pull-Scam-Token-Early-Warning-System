#!/usr/bin/env python3
"""
RugPull Detector — CLI entry point
Usage: python -m src.main <contract_address> [options]
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path

from src.analyzers.contract_analyzer import ContractAnalyzer
from src.collectors.social_collector import SocialCollector
from src.utils.report import generate_report, print_terminal_report

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("rugpull-detector")

BANNER = r"""
 ██████╗ ██╗   ██╗ ██████╗     ██████╗ ██╗   ██╗██╗     ██╗
 ██╔══██╗██║   ██║██╔════╝     ██╔══██╗██║   ██║██║     ██║
 ██████╔╝██║   ██║██║  ███╗    ██████╔╝██║   ██║██║     ██║
 ██╔══██╗██║   ██║██║   ██║    ██╔═══╝ ██║   ██║██║     ██║
 ██║  ██║╚██████╔╝╚██████╔╝    ██║     ╚██████╔╝███████╗███████╗
 ╚═╝  ╚═╝ ╚═════╝  ╚═════╝     ╚═╝      ╚═════╝ ╚══════╝╚══════╝

 DETECTOR  ·  Rug Pull & Scam Token Early Warning System  v1.0.0
 ─────────────────────────────────────────────────────────────────
"""


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="rugpull-detector",
        description="Analyze smart contracts and social signals for rug pull risk",
    )
    p.add_argument("address", nargs="?", help="Contract address to analyze")
    p.add_argument("--token", "-t", help="Token name/symbol for social analysis")
    p.add_argument("--rpc", default=os.getenv("RPC_URL", "https://eth.llamarpc.com"),
                   help="EVM RPC endpoint URL")
    p.add_argument("--etherscan-key", default=os.getenv("ETHERSCAN_API_KEY"),
                   help="Etherscan API key (enables source code checks)")
    p.add_argument("--twitter-key", default=os.getenv("TWITTER_BEARER_TOKEN"),
                   help="Twitter Bearer token (enables social analysis)")
    p.add_argument("--output", "-o", choices=["terminal", "json", "both"],
                   default="terminal", help="Output format")
    p.add_argument("--save", "-s", metavar="FILE",
                   help="Save JSON report to file")
    p.add_argument("--no-social", action="store_true",
                   help="Skip social signal analysis")
    p.add_argument("--chain", choices=["eth", "bsc", "polygon", "arb"],
                   default="eth", help="Blockchain network")
    return p


def run(args: argparse.Namespace) -> int:
    print(BANNER)

    if not args.address:
        print("ERROR: contract address is required.\n")
        print("  Example: python -m src.main 0xTokenAddress --token PEPE\n")
        return 1

    # ── Contract analysis ──────────────────────────────────────────
    logger.info("Starting contract analysis for %s on %s", args.address, args.chain)
    try:
        analyzer = ContractAnalyzer(
            rpc_url=args.rpc,
            etherscan_api_key=args.etherscan_key,
        )
        contract_risk = analyzer.analyze(args.address)
    except ConnectionError as exc:
        print(f"\nERROR: Cannot connect to RPC endpoint — {exc}")
        print("Tip: set RPC_URL environment variable or use --rpc flag.\n")
        return 2
    except Exception as exc:
        logger.error("Contract analysis failed: %s", exc)
        return 3

    # ── Social analysis ────────────────────────────────────────────
    social_report = None
    if not args.no_social and args.token:
        logger.info("Starting social analysis for %s", args.token)
        collector = SocialCollector(twitter_bearer=args.twitter_key)
        social_report = collector.analyze(args.token, args.address)

    # ── Report ─────────────────────────────────────────────────────
    report = generate_report(contract_risk, social_report)

    if args.output in ("terminal", "both"):
        print_terminal_report(report)

    if args.output in ("json", "both"):
        print(json.dumps(report, indent=2, default=str))

    if args.save:
        path = Path(args.save)
        path.write_text(json.dumps(report, indent=2, default=str))
        logger.info("Report saved to %s", path.resolve())

    # Exit code reflects risk level
    exit_codes = {"low": 0, "medium": 0, "high": 1, "critical": 2}
    return exit_codes.get(contract_risk.level, 0)


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    sys.exit(run(args))


if __name__ == "__main__":
    main()
