"""
Contract Analyzer — Core module for smart contract risk assessment.
Analyzes on-chain data to detect rug pull indicators and scam patterns.
"""

import re
import json
import time
import logging
from dataclasses import dataclass, field
from typing import Optional
from web3 import Web3

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# Risk scoring weights (tunable)
# ─────────────────────────────────────────────
RISK_WEIGHTS = {
    "no_source_code":          30,
    "mint_function":           20,
    "ownership_not_renounced": 15,
    "honeypot_pattern":        25,
    "high_owner_supply":       20,
    "no_liquidity_lock":       20,
    "proxy_contract":          10,
    "self_destruct":           25,
    "blacklist_function":      20,
    "fee_manipulation":        15,
    "low_liquidity":           15,
    "young_contract":          10,
    "few_holders":             10,
}

RISK_THRESHOLDS = {
    "low":      (0,  30),
    "medium":   (31, 59),
    "high":     (60, 79),
    "critical": (80, 100),
}


@dataclass
class ContractRisk:
    address: str
    score: int = 0                          # 0–100
    level: str = "unknown"
    flags: list[str] = field(default_factory=list)
    details: dict = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "address":   self.address,
            "score":     self.score,
            "level":     self.level,
            "flags":     self.flags,
            "details":   self.details,
            "timestamp": self.timestamp,
        }


class ContractAnalyzer:
    """
    Analyzes EVM-compatible smart contracts for rug pull and scam indicators.

    Checks performed
    ────────────────
    • Source code verification (Etherscan/BSCScan)
    • Dangerous function detection (mint, blacklist, pause, selfdestruct)
    • Ownership status (renounced vs active)
    • Liquidity lock verification
    • Token holder distribution
    • Proxy / upgradeable contract patterns
    • Contract age heuristics
    • Honeypot simulation (buy-sell tax imbalance)
    """

    # Common dangerous function signatures (4-byte selectors)
    DANGEROUS_SELECTORS = {
        "0x40c10f19": "mint(address,uint256)",
        "0x42966c68": "burn(uint256)",
        "0xff2b5b73": "blacklist(address)",
        "0x4f9eab65": "setFee(uint256)",
        "0x69328dec": "rescueToken(address,uint256)",
        "0xe9dae5ed": "setMaxTxAmount(uint256)",
    }

    HONEYPOT_PATTERNS = [
        r"require\s*\(\s*from\s*==\s*owner",
        r"_isBlacklisted\[",
        r"tradingEnabled\s*=\s*false",
        r"require\s*\(\s*!_isSniper",
        r"cooldown\[",
    ]

    def __init__(self, rpc_url: str, etherscan_api_key: Optional[str] = None):
        self.w3 = Web3(Web3.HTTPProvider(rpc_url))
        self.etherscan_key = etherscan_api_key
        if not self.w3.is_connected():
            raise ConnectionError(f"Cannot connect to RPC: {rpc_url}")
        logger.info("ContractAnalyzer ready — chain id %s", self.w3.eth.chain_id)

    # ─────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────

    def analyze(self, address: str) -> ContractRisk:
        """Full risk analysis pipeline for a contract address."""
        address = Web3.to_checksum_address(address)
        risk = ContractRisk(address=address)

        checks = [
            self._check_source_code,
            self._check_dangerous_functions,
            self._check_ownership,
            self._check_liquidity,
            self._check_holder_distribution,
            self._check_contract_age,
            self._check_proxy_pattern,
        ]

        for check in checks:
            try:
                check(address, risk)
            except Exception as exc:
                logger.warning("Check %s failed: %s", check.__name__, exc)

        risk.score = min(100, risk.score)
        risk.level = self._score_to_level(risk.score)
        return risk

    # ─────────────────────────────────────────
    # Individual checks
    # ─────────────────────────────────────────

    def _check_source_code(self, address: str, risk: ContractRisk) -> None:
        """Verify contract source code is published and scan for patterns."""
        bytecode = self.w3.eth.get_code(address).hex()

        if bytecode in ("0x", ""):
            risk.flags.append("not_a_contract")
            risk.score += 50
            return

        # Check for selfdestruct opcode (0xff)
        if "ff" in bytecode[2:]:
            risk.flags.append("self_destruct")
            risk.score += RISK_WEIGHTS["self_destruct"]
            risk.details["self_destruct"] = "SELFDESTRUCT opcode found in bytecode"

        # Check dangerous selectors in bytecode
        for selector, sig in self.DANGEROUS_SELECTORS.items():
            if selector[2:] in bytecode:
                flag = sig.split("(")[0]
                if flag not in risk.flags:
                    risk.flags.append(flag)
                    risk.score += RISK_WEIGHTS.get("mint_function", 10)
                    risk.details[flag] = f"Dangerous function detected: {sig}"

        # Source code verification via Etherscan API
        if self.etherscan_key:
            source = self._fetch_source_code(address)
            if not source:
                risk.flags.append("no_source_code")
                risk.score += RISK_WEIGHTS["no_source_code"]
                risk.details["no_source_code"] = "Contract source not verified on Etherscan"
            else:
                self._scan_source_patterns(source, risk)

    def _scan_source_patterns(self, source: str, risk: ContractRisk) -> None:
        """Search Solidity source for honeypot / scam patterns."""
        for pattern in self.HONEYPOT_PATTERNS:
            if re.search(pattern, source, re.IGNORECASE):
                if "honeypot_pattern" not in risk.flags:
                    risk.flags.append("honeypot_pattern")
                    risk.score += RISK_WEIGHTS["honeypot_pattern"]
                    risk.details["honeypot_pattern"] = f"Suspicious pattern: {pattern}"
                break

        if re.search(r"setFee|_taxFee\s*=", source) and re.search(r"\d{2,}", source):
            risk.flags.append("fee_manipulation")
            risk.score += RISK_WEIGHTS["fee_manipulation"]
            risk.details["fee_manipulation"] = "Dynamic fee setter with high values detected"

        if re.search(r"blacklist|_isBlacklisted", source, re.IGNORECASE):
            risk.flags.append("blacklist_function")
            risk.score += RISK_WEIGHTS["blacklist_function"]
            risk.details["blacklist_function"] = "Address blacklisting mechanism found"

    def _check_ownership(self, address: str, risk: ContractRisk) -> None:
        """Check if ownership has been renounced (burned to 0x000…dead)."""
        dead_addresses = {
            "0x0000000000000000000000000000000000000000",
            "0x000000000000000000000000000000000000dEaD",
        }
        # Try standard Ownable ABI
        owner_sig = self.w3.keccak(text="owner()")[:4]
        try:
            result = self.w3.eth.call({"to": address, "data": owner_sig})
            owner = "0x" + result.hex()[-40:]
            if owner.lower() not in {a.lower() for a in dead_addresses}:
                risk.flags.append("ownership_not_renounced")
                risk.score += RISK_WEIGHTS["ownership_not_renounced"]
                risk.details["owner"] = owner
        except Exception:
            pass  # Contract may not implement Ownable

    def _check_liquidity(self, address: str, risk: ContractRisk) -> None:
        """Heuristic: check ETH balance as proxy for on-chain liquidity."""
        balance_wei = self.w3.eth.get_balance(address)
        balance_eth = self.w3.from_wei(balance_wei, "ether")
        risk.details["contract_balance_eth"] = float(balance_eth)

        if balance_eth < 0.5:
            risk.flags.append("low_liquidity")
            risk.score += RISK_WEIGHTS["low_liquidity"]
            risk.details["low_liquidity"] = f"Contract holds only {balance_eth:.4f} ETH"

    def _check_holder_distribution(self, address: str, risk: ContractRisk) -> None:
        """Placeholder — real impl queries Etherscan token holders endpoint."""
        # Without Etherscan key, skip silently
        if not self.etherscan_key:
            return
        holders = self._fetch_top_holders(address)
        if holders is None:
            return
        if len(holders) < 50:
            risk.flags.append("few_holders")
            risk.score += RISK_WEIGHTS["few_holders"]
            risk.details["few_holders"] = f"Only {len(holders)} unique holders found"

        if holders:
            top_pct = holders[0].get("percent", 0)
            if top_pct > 20:
                risk.flags.append("high_owner_supply")
                risk.score += RISK_WEIGHTS["high_owner_supply"]
                risk.details["high_owner_supply"] = f"Top holder owns {top_pct:.1f}% of supply"

    def _check_contract_age(self, address: str, risk: ContractRisk) -> None:
        """Flag contracts deployed within the last 7 days."""
        tx_count = self.w3.eth.get_transaction_count(address)
        risk.details["tx_count"] = tx_count
        # Age heuristic via nonce / block — simplified
        latest = self.w3.eth.block_number
        # Without Etherscan, we can't get exact deploy block easily
        if tx_count < 10:
            risk.flags.append("young_contract")
            risk.score += RISK_WEIGHTS["young_contract"]
            risk.details["young_contract"] = "Very low transaction count — possibly new contract"

    def _check_proxy_pattern(self, address: str, risk: ContractRisk) -> None:
        """Detect EIP-1967 transparent / UUPS proxy patterns."""
        # EIP-1967 implementation slot
        impl_slot = "0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc"
        try:
            slot_value = self.w3.eth.get_storage_at(address, impl_slot)
            if int(slot_value.hex(), 16) != 0:
                risk.flags.append("proxy_contract")
                risk.score += RISK_WEIGHTS["proxy_contract"]
                risk.details["proxy_impl"] = "0x" + slot_value.hex()[-40:]
        except Exception:
            pass

    # ─────────────────────────────────────────
    # Etherscan API helpers
    # ─────────────────────────────────────────

    def _fetch_source_code(self, address: str) -> Optional[str]:
        import urllib.request
        url = (
            f"https://api.etherscan.io/api?module=contract&action=getsourcecode"
            f"&address={address}&apikey={self.etherscan_key}"
        )
        try:
            with urllib.request.urlopen(url, timeout=10) as resp:
                data = json.loads(resp.read())
            result = data.get("result", [{}])[0]
            return result.get("SourceCode") or None
        except Exception as exc:
            logger.warning("Etherscan source fetch failed: %s", exc)
            return None

    def _fetch_top_holders(self, address: str) -> Optional[list]:
        """Returns list of top token holders (Etherscan Pro endpoint)."""
        # Etherscan Pro required — graceful degradation
        return None

    # ─────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────

    @staticmethod
    def _score_to_level(score: int) -> str:
        for level, (lo, hi) in RISK_THRESHOLDS.items():
            if lo <= score <= hi:
                return level
        return "critical"
