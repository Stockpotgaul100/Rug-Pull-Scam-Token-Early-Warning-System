"""
Social Signals Collector — aggregates Twitter/X, Telegram, Reddit signals
for early warning detection of coordinated pump-and-dump and rug pull schemes.
"""

import re
import time
import logging
import urllib.request
import urllib.parse
import json
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class SocialSignal:
    platform: str
    score: int = 0          # 0-100 risk score
    flags: list[str] = field(default_factory=list)
    metrics: dict = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "platform":  self.platform,
            "score":     self.score,
            "flags":     self.flags,
            "metrics":   self.metrics,
            "timestamp": self.timestamp,
        }


@dataclass
class SocialReport:
    token_name: str
    combined_score: int = 0
    signals: list[SocialSignal] = field(default_factory=list)
    summary_flags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "token_name":     self.token_name,
            "combined_score": self.combined_score,
            "signals":        [s.to_dict() for s in self.signals],
            "summary_flags":  self.summary_flags,
        }


# ─────────────────────────────────────────────
# Heuristic patterns — updated regularly
# ─────────────────────────────────────────────

PUMP_PHRASES = [
    r"\b(100x|1000x|moon|gem|hidden gem|next\s*\d+x)\b",
    r"\b(guaranteed|risk.free|safe\s*investment|can't\s*lose)\b",
    r"\b(aping|degen|yolo|send\s*it)\b",
    r"🚀{2,}",
    r"💎{2,}",
]

URGENCY_PHRASES = [
    r"\b(last chance|limited time|act now|don't\s*miss|hurry)\b",
    r"\b(presale|private\s*sale|whitelist\s*closing)\b",
    r"\b(buy\s*now|get\s*in\s*early|early\s*bird)\b",
]

SUSPICIOUS_ACCOUNT_PATTERNS = [
    r"^[A-Za-z]{3,6}\d{4,}$",     # RandomWord1234
    r"^[A-Z][a-z]+[A-Z][a-z]+\d+", # CamelCase1234
]

FAKE_TEAM_PATTERNS = [
    r"\b(doxxed team|fully\s*doxxed|verified\s*team)\b",
    r"\b(ex.*(google|meta|amazon|microsoft|binance|coinbase))\b",
    r"\b(serial entrepreneur|blockchain expert|visionary)\b",
]


class SocialCollector:
    """
    Collects and scores social media signals for a given token/project.

    Platforms covered
    ─────────────────
    • Twitter/X  — keyword frequency, account age heuristics, bot patterns
    • Telegram   — member count velocity, admin transparency
    • Reddit     — post karma, comment patterns, upvote manipulation signals
    • CoinGecko  — watchlist / sentiment data (public API, no key required)
    """

    def __init__(
        self,
        twitter_bearer: Optional[str] = None,
        telegram_bot_token: Optional[str] = None,
    ):
        self.twitter_bearer = twitter_bearer
        self.telegram_bot_token = telegram_bot_token

    # ─────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────

    def analyze(self, token_name: str, contract_address: Optional[str] = None) -> SocialReport:
        report = SocialReport(token_name=token_name)

        collectors = [
            self._analyze_coingecko,
            self._analyze_twitter,
            self._analyze_telegram,
        ]

        for collector in collectors:
            try:
                signal = collector(token_name, contract_address)
                if signal:
                    report.signals.append(signal)
            except Exception as exc:
                logger.warning("Collector %s failed: %s", collector.__name__, exc)

        if report.signals:
            report.combined_score = min(
                100, sum(s.score for s in report.signals) // len(report.signals)
            )
            for s in report.signals:
                report.summary_flags.extend(s.flags)
            report.summary_flags = list(set(report.summary_flags))

        return report

    # ─────────────────────────────────────────
    # CoinGecko (no API key required)
    # ─────────────────────────────────────────

    def _analyze_coingecko(
        self, token_name: str, address: Optional[str]
    ) -> Optional[SocialSignal]:
        signal = SocialSignal(platform="coingecko")
        query = urllib.parse.quote(token_name.lower())
        url = f"https://api.coingecko.com/api/v3/search?query={query}"

        try:
            req = urllib.request.Request(url, headers={"User-Agent": "RugPullDetector/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
        except Exception as exc:
            logger.warning("CoinGecko fetch failed: %s", exc)
            return None

        coins = data.get("coins", [])
        if not coins:
            signal.flags.append("not_on_coingecko")
            signal.score += 10
            signal.metrics["found"] = False
            return signal

        coin = coins[0]
        signal.metrics["market_cap_rank"] = coin.get("market_cap_rank")
        signal.metrics["name"] = coin.get("name")

        rank = coin.get("market_cap_rank")
        if rank is None:
            signal.flags.append("no_market_cap_rank")
            signal.score += 15
        elif rank > 2000:
            signal.flags.append("very_low_market_cap_rank")
            signal.score += 10

        return signal

    # ─────────────────────────────────────────
    # Twitter / X  (Bearer token required)
    # ─────────────────────────────────────────

    def _analyze_twitter(
        self, token_name: str, address: Optional[str]
    ) -> Optional[SocialSignal]:
        if not self.twitter_bearer:
            logger.info("Twitter analysis skipped — no bearer token configured")
            return None

        signal = SocialSignal(platform="twitter")
        query = urllib.parse.quote(f"${token_name} OR #{token_name} lang:en -is:retweet")
        url = (
            "https://api.twitter.com/2/tweets/search/recent"
            f"?query={query}&max_results=100"
            "&tweet.fields=created_at,public_metrics,author_id"
        )
        headers = {"Authorization": f"Bearer {self.twitter_bearer}"}

        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
        except Exception as exc:
            logger.warning("Twitter API failed: %s", exc)
            return None

        tweets = data.get("data", [])
        signal.metrics["tweet_count"] = len(tweets)

        pump_hits = 0
        urgency_hits = 0
        for tweet in tweets:
            text = tweet.get("text", "")
            for p in PUMP_PHRASES:
                if re.search(p, text, re.IGNORECASE):
                    pump_hits += 1
                    break
            for p in URGENCY_PHRASES:
                if re.search(p, text, re.IGNORECASE):
                    urgency_hits += 1
                    break

        signal.metrics["pump_phrase_hits"] = pump_hits
        signal.metrics["urgency_phrase_hits"] = urgency_hits

        pump_ratio = pump_hits / max(len(tweets), 1)
        if pump_ratio > 0.4:
            signal.flags.append("coordinated_pump_language")
            signal.score += 25
        elif pump_ratio > 0.2:
            signal.flags.append("elevated_pump_language")
            signal.score += 12

        if urgency_hits > 10:
            signal.flags.append("urgency_tactics")
            signal.score += 15

        if len(tweets) > 80:
            signal.flags.append("high_tweet_velocity")
            signal.score += 10

        return signal

    # ─────────────────────────────────────────
    # Telegram  (Bot token required)
    # ─────────────────────────────────────────

    def _analyze_telegram(
        self, token_name: str, address: Optional[str]
    ) -> Optional[SocialSignal]:
        if not self.telegram_bot_token:
            logger.info("Telegram analysis skipped — no bot token configured")
            return None

        signal = SocialSignal(platform="telegram")
        # Without a known chat id we can't query; real impl would maintain a
        # registry of known project chats scraped from project websites.
        signal.metrics["note"] = "Telegram analysis requires known chat username"
        return signal

    # ─────────────────────────────────────────
    # Text pattern helpers (public utility)
    # ─────────────────────────────────────────

    @staticmethod
    def score_text(text: str) -> dict:
        """
        Standalone text scorer — returns pump/urgency/fake-team flag counts.
        Useful for scoring whitepaper, website copy, or Telegram messages.
        """
        results = {"pump": 0, "urgency": 0, "fake_team": 0}
        for p in PUMP_PHRASES:
            if re.search(p, text, re.IGNORECASE):
                results["pump"] += 1
        for p in URGENCY_PHRASES:
            if re.search(p, text, re.IGNORECASE):
                results["urgency"] += 1
        for p in FAKE_TEAM_PATTERNS:
            if re.search(p, text, re.IGNORECASE):
                results["fake_team"] += 1
        return results
