# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 2.x.x   | ✅ Active support |
| 1.x.x   | ⚠️ Critical fixes only |
| < 1.0   | ❌ No support |

---

## Reporting a Vulnerability

RugPull Detector is a **security tool** — its integrity is critical. If you find a vulnerability in this project (not in third-party contracts it analyzes), please follow responsible disclosure.

### Do NOT open a public GitHub Issue for security vulnerabilities.

### Instead:

1. **Email:** open a [GitHub Security Advisory](../../security/advisories/new) (private, only maintainers see it)
2. **Include:**
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if you have one)

We will acknowledge receipt within **48 hours** and aim to release a patch within **14 days** for critical issues.

---

## Scope

### In scope
- Code execution vulnerabilities in the analyzer or CLI
- API key or credential leakage through logs or output
- Dependency vulnerabilities with a working exploit
- False negative patterns that could be deliberately exploited to evade detection

### Out of scope
- Vulnerabilities in third-party contracts being analyzed
- Issues requiring physical access to the user's machine
- Social engineering attacks against users
- Theoretical vulnerabilities without a proof of concept

---

## Our Commitments

- We will not take legal action against good-faith security researchers
- We will credit reporters in the release notes (unless anonymity is requested)
- We will keep you informed of fix progress

---

## Dependency Security

This project uses `pip` for dependency management. To audit your installed packages:

```bash
pip install pip-audit
pip-audit
```

Known safe versions are pinned in `requirements.txt`. Always use a virtual environment.

---

## A Note on Intended Use

This tool is designed **exclusively** to help users identify potentially fraudulent token projects. Any use of this codebase to build tools that facilitate fraud, evade security checks, or harm crypto users violates the MIT license terms and this policy. Such use will be reported to relevant authorities where applicable.
