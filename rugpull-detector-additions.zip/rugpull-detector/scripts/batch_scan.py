#!/usr/bin/env python3
"""
Batch Scanner — analyze multiple contracts from a CSV file.

Usage:
    python scripts/batch_scan.py contracts.csv
    python scripts/batch_scan.py contracts.csv --output results.json
    python scripts/batch_scan.py contracts.csv --min-risk high

CSV format (header required):
    address,token_name
    0xABC...,PEPE
    0xDEF...,WOJAK
"""

import argparse
import csv
import json
import logging
import os
import sys
import time
from pathlib import Path

# Allow running from project root
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.analyzers.contract_analyzer import ContractAnalyzer
from src.collectors.social_collector import SocialCollector
from src.utils.report import generate_report

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("batch-scan")

RISK_ORDER = {"low": 0, "medium": 1, "high": 2, "critical": 3}


def parse_csv(path: str) -> list[dict]:
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            address = row.get("address", "").strip()
            if address:
                rows.append({
                    "address": address,
                    "token_name": row.get("token_name", "").strip(),
                })
    return rows


def run_batch(args: argparse.Namespace) -> None:
    contracts = parse_csv(args.csv)
    logger.info("Loaded %d contracts from %s", len(contracts), args.csv)

    analyzer = ContractAnalyzer(
        rpc_url=os.getenv("RPC_URL", "https://eth.llamarpc.com"),
        etherscan_api_key=os.getenv("ETHERSCAN_API_KEY"),
    )
    collector = SocialCollector(twitter_bearer=os.getenv("TWITTER_BEARER_TOKEN"))

    results = []
    min_level = RISK_ORDER.get(args.min_risk, 0)

    for i, entry in enumerate(contracts, 1):
        address = entry["address"]
        token = entry["token_name"]
        logger.info("[%d/%d] Analyzing %s %s", i, len(contracts), address, f"({token})" if token else "")

        try:
            contract_risk = analyzer.analyze(address)
            social_report = collector.analyze(token, address) if token else None
            report = generate_report(contract_risk, social_report)

            level = report["overall_level"]
            if RISK_ORDER.get(level, 0) >= min_level:
                results.append(report)
                flag = "⚠️ " if level in ("high", "critical") else "  "
                print(f"  {flag}{address}  [{level.upper():8}]  {report['overall_score']:3}/100  {token}")

        except Exception as exc:
            logger.warning("Failed to analyze %s: %s", address, exc)
            results.append({"address": address, "error": str(exc)})

        # Rate-limit courtesy pause
        if i < len(contracts):
            time.sleep(args.delay)

    # Summary
    levels = [r.get("overall_level", "error") for r in results]
    print(f"\n{'─'*55}")
    print(f"  Scanned: {len(contracts)}   Reported: {len(results)}")
    for lvl in ("critical", "high", "medium", "low"):
        count = levels.count(lvl)
        if count:
            print(f"  {lvl.upper():8}: {count}")
    print(f"{'─'*55}\n")

    if args.output:
        Path(args.output).write_text(json.dumps(results, indent=2, default=str))
        logger.info("Results saved to %s", args.output)


def main() -> None:
    p = argparse.ArgumentParser(description="Batch contract risk scanner")
    p.add_argument("csv", help="Path to CSV file with contract addresses")
    p.add_argument("--output", "-o", help="Save JSON results to file")
    p.add_argument("--min-risk", choices=["low", "medium", "high", "critical"],
                   default="low", help="Only report contracts at or above this risk level")
    p.add_argument("--delay", type=float, default=0.5,
                   help="Seconds to wait between requests (default: 0.5)")
    args = p.parse_args()
    run_batch(args)


if __name__ == "__main__":
    main()
