# Contributing to RugPull Detector

Thank you for helping make DeFi safer. Every contribution — bug fix, new risk check, documentation improvement, or translation — matters.

---

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How to Contribute](#how-to-contribute)
- [Adding a New Risk Check](#adding-a-new-risk-check)
- [Development Setup](#development-setup)
- [Pull Request Guidelines](#pull-request-guidelines)
- [Reporting Bugs](#reporting-bugs)
- [Style Guide](#style-guide)

---

## Code of Conduct

This project exists to **protect** crypto users from fraud — not to enable it. All contributions must align with this goal. Any submission that could be used offensively (e.g. to build scam contracts that evade detection) will be rejected and the contributor banned.

Be respectful. Be constructive. Focus on the mission.

---

## How to Contribute

### Good first contributions
- Fix a bug listed in [Issues](../../issues)
- Improve documentation or fix typos
- Add a new regex pattern to `HONEYPOT_PATTERNS` or `PUMP_PHRASES`
- Write a missing unit test
- Add support for a new EVM chain

### Larger contributions
- New risk check module
- New social platform collector
- Batch analysis mode
- Web dashboard

For larger changes, **open an Issue first** to discuss the approach before writing code.

---

## Adding a New Risk Check

This is the most valuable type of contribution. Here's the full workflow:

### 1. Add the weight to `RISK_WEIGHTS`

```python
# src/analyzers/contract_analyzer.py

RISK_WEIGHTS = {
    ...
    "your_new_check": 15,   # choose 10–30 based on severity
}
```

### 2. Implement the check method

```python
def _check_your_new_check(self, address: str, risk: ContractRisk) -> None:
    """
    One-line description of what this detects.
    
    Why it matters: explain the attack vector.
    """
    # your logic here
    if suspicious_condition:
        risk.flags.append("your_new_check")
        risk.score += RISK_WEIGHTS["your_new_check"]
        risk.details["your_new_check"] = "Human-readable explanation of what was found"
```

### 3. Register it in `analyze()`

```python
checks = [
    ...
    self._check_your_new_check,
]
```

### 4. Write the test

```python
# tests/test_analyzer.py

def test_your_new_check_detected(self):
    analyzer = _mock_analyzer()
    risk = ContractRisk(address="0x0")
    # set up conditions
    analyzer._check_your_new_check("0x0", risk)
    assert "your_new_check" in risk.flags

def test_your_new_check_not_triggered_on_clean(self):
    analyzer = _mock_analyzer()
    risk = ContractRisk(address="0x0")
    # ensure clean condition
    assert risk.flags == []
```

### 5. Document it in README

Add a row to the **Risk Factors & Weights** table.

---

## Development Setup

```bash
# Fork and clone
git clone https://github.com/YOUR_USERNAME/Rug-Pull-Scam-Token-Early-Warning-System.git
cd Rug-Pull-Scam-Token-Early-Warning-System

# Create virtual environment
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

# Install dependencies + dev tools
pip install -r requirements.txt
pip install pytest pytest-cov

# Copy environment config
cp .env.example .env

# Run tests to verify setup
pytest tests/ -v
```

---

## Pull Request Guidelines

1. **One PR per feature or fix** — keep changes focused
2. **All tests must pass** — run `pytest tests/ -v` before submitting
3. **New checks need tests** — PRs without tests for new checks will be held
4. **Update README** — if you add a risk factor, add it to the table
5. **Descriptive commit messages** — `feat: add transfer_limit check` not `fix stuff`
6. **No breaking changes** — keep CLI flags and JSON output format stable

### Commit message format

```
type: short description

feat:     new feature
fix:      bug fix
docs:     documentation only
test:     tests only
refactor: code change without feature/fix
chore:    tooling, CI, deps
```

---

## Reporting Bugs

Use the [Bug Report template](../../issues/new?template=bug_report.md).

Include:
- Python version and OS
- Full command you ran
- Full terminal output (redact any API keys)
- Contract address if the issue is analysis-specific (testnet preferred)

---

## Style Guide

- **Python 3.10+** — use modern type hints (`list[str]` not `List[str]`)
- **Docstrings** — every public method needs one
- **No external formatters required** — but keep lines under 100 chars
- **Logging over print** — use `logger.info/warning/error`, not `print()`
- **Fail gracefully** — wrap external API calls in try/except, log warnings, continue

---

## Questions?

Open a [Discussion](../../discussions) or an [Issue](../../issues) — we're happy to help onboard new contributors.
